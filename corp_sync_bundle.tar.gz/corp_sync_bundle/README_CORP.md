# SOT sync daemon on the Corp Anytype machine

Requires: Linux x86_64, glibc >= 2.28, Python 3.11 / 3.12 / 3.13.
If `python3 --version` says anything else, STOP and report the version —
the wheels/ folder must be rebuilt for it (5 minutes on Lily's side).

## Install (offline, no network)

    sh install.sh

## One-time setup

1. Pair with Anytype (the Anytype desktop app must be OPEN on this machine):

       cd anytype_sync
       ../.venv/bin/python pair.py

   A 4-digit code appears inside Anytype; type it at the prompt. If the OS
   keyring is unavailable the script PRINTS the token — export it instead:

       export ANYTYPE_API_TOKEN=<printed value>

2. SOT API token (Lily mints a dedicated one in SOT Admin, shown once):

       export SOTC_API_TOKEN=<token>

## Run — always from the anytype_sync/ directory

    cd anytype_sync
    ../.venv/bin/python sync_client.py --dry-run   # prints payload, sends NOTHING
    ../.venv/bin/python sync_client.py --push      # one real push
    ../.venv/bin/python sync_client.py --daemon 10 # steady state, every 10 min

The vault passphrase is prompted once at start and held in process memory
only (or set SOTC_VAULT_PASSPHRASE for unattended starts — a policy call,
not the default). Restart the daemon after ANY change to sync.yml.

## What success looks like

The SOT app's freshness chip (Corp kiosk) reads
"sot_research_2026 · synced Nm ago" with N in minutes, and project/task
counts match Anytype.

## Notes

- sync.yml ships preconfigured: server http://sot.kx-71.com, vault
  ../tokenization/vault.blob (relative paths — hence "run from anytype_sync/").
- The bundled vault.blob is the current one from Lily's laptop at build
  time; Translate readers on Corp should switch to it if theirs is older.
- Names never leave this machine in plaintext: unknown names are withheld
  and queued in tokenization/pending_mints.json until minted.
- No secrets are in this bundle. Tokens arrive as environment variables;
  the passphrase is typed by Lily.
