"""
vault.py — the SOT tokenization vault (docs/TOKENIZATION_VAULT_HANDOFF.md).

An encrypted blob mapping anytype_uuid -> token -> plaintext, living ONLY on
operator/analyst/developer laptops. INVARIANTS (do not break):
  - the vault and its key NEVER touch the server;
  - tokenization keys on anytype_uuid, never the display string;
  - plaintext obtained from the vault is ephemeral — never persisted.

Crypto (v1, per handoff §3 "passphrase-derived"; custody swappable):
  PBKDF2-SHA256(passphrase, salt, 300k) -> 64 bytes:
    [0:32] AES-256-GCM key (confidentiality + integrity)
    [32:]  HMAC-SHA256 key  (distribution signature over the ciphertext)
  Chosen to be WebCrypto-compatible so the browser extension opens the same
  blob with the same passphrase.

Envelope (JSON on disk):
  { "format": "sot-vault-1",
    "kdf": {"alg": "PBKDF2-SHA256", "salt": b64, "iterations": 300000},
    "nonce": b64, "ciphertext": b64, "sig": b64 }

Payload (JSON, encrypted):
  { "vault_version": int,          # monotonic; bumped on every curation change
    "entries": [ {anytype_uuid, token, namespace, plaintext,
                  status: "active"|"retired", minted_under_version} ],
    "pools": { "proj": {"available": [...], "used": [...]},
               "org": {...}, "person_adj": {...}, "person_noun": {...} } }

Deps: pip install cryptography
"""

from __future__ import annotations

import base64
import hashlib
import hmac as hmac_mod
import json
import os
import secrets
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

KDF_ITERATIONS = 300_000
FORMAT = "sot-vault-1"
# "manual" (trees pool, Lily 2026-07-31): explicit/manual, non-Anytype entities
# — visibly distinct from minerals (synced projects) / rivers (orgs) /
# adjective+animal (persons).
# "contact" (lakes pool) + person->cartoons (Lily 2026-08-09, CRM
# tokenization): CRM contacts draw single lake names; the person namespace
# now draws single cartoon-character names for SOT users/People. Vaults
# created before the cartoons pool fall back to adjective+animal — run
# `vault_tool.py extend` to add the new pools to an existing vault.
# "tf" (mountains) + "domain" (seas) — Lily 2026-08-13: the task-force and
# domain names ARE the compartment map and leave the DB like every other name.
NAMESPACES = ("proj", "org", "person", "manual", "contact", "tf", "domain")

# namespace/pool -> seed file. Single source for create() and extend_pools().
POOL_FILES = (("proj", "minerals.txt"), ("org", "rivers.txt"),
              ("person_adj", "adjectives.txt"), ("person_noun", "animals.txt"),
              ("manual", "trees.txt"), ("contact", "lakes.txt"),
              ("person_char", "cartoons.txt"),
              ("person_star", "stars.txt"),
              ("tf", "mountains.txt"), ("domain", "seas.txt"))


def _derive(passphrase: str, salt: bytes, iterations: int) -> tuple[bytes, bytes]:
    master = hashlib.pbkdf2_hmac("sha256", passphrase.encode("utf-8"), salt,
                                 iterations, dklen=64)
    return master[:32], master[32:]


def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def _unb64(s: str) -> bytes:
    return base64.b64decode(s)


class VaultError(SystemExit):
    pass


class Vault:
    """One canonical map, two lookup directions (uuid->token, token->plaintext)."""

    def __init__(self, payload: dict, path: Path, passphrase: str):
        self._p = payload
        self._path = path
        self._passphrase = passphrase

    # ── open / save ──────────────────────────────────────────────────────
    @classmethod
    def create(cls, path: Path, passphrase: str, pools_dir: Path) -> "Vault":
        if path.exists():
            raise VaultError(f"{path} already exists")
        pools = {}
        for ns, fname in POOL_FILES:
            words = [w.strip() for w in (pools_dir / fname).read_text(encoding="utf-8").splitlines()
                     if w.strip() and not w.startswith("#")]
            pools[ns] = {"available": words, "used": []}
        v = cls({"vault_version": 1, "entries": [], "pools": pools}, path, passphrase)
        v.save()
        return v

    @classmethod
    def open(cls, path: Path, passphrase: str) -> "Vault":
        if not path.is_file():
            raise VaultError(f"vault not found: {path}")
        env = json.loads(path.read_text(encoding="utf-8"))
        if env.get("format") != FORMAT:
            raise VaultError(f"unknown vault format {env.get('format')!r}")
        salt = _unb64(env["kdf"]["salt"])
        enc_key, sig_key = _derive(passphrase, salt, int(env["kdf"]["iterations"]))
        ct = _unb64(env["ciphertext"])
        expect = hmac_mod.new(sig_key, ct, hashlib.sha256).digest()
        if not hmac_mod.compare_digest(expect, _unb64(env["sig"])):
            raise VaultError("vault signature check FAILED — wrong passphrase or tampered blob")
        try:
            plain = AESGCM(enc_key).decrypt(_unb64(env["nonce"]), ct, None)
        except Exception:  # noqa: BLE001
            raise VaultError("vault decrypt failed — wrong passphrase or corrupted blob") from None
        return cls(json.loads(plain.decode("utf-8")), path, passphrase)

    def save(self) -> None:
        salt = secrets.token_bytes(16)
        nonce = secrets.token_bytes(12)
        enc_key, sig_key = _derive(self._passphrase, salt, KDF_ITERATIONS)
        ct = AESGCM(enc_key).encrypt(nonce, json.dumps(self._p).encode("utf-8"), None)
        env = {
            "format": FORMAT,
            "kdf": {"alg": "PBKDF2-SHA256", "salt": _b64(salt), "iterations": KDF_ITERATIONS},
            "nonce": _b64(nonce),
            "ciphertext": _b64(ct),
            "sig": _b64(hmac_mod.new(sig_key, ct, hashlib.sha256).digest()),
        }
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(env, indent=1), encoding="utf-8")
        os.replace(tmp, self._path)

    def rekey(self, new_passphrase: str) -> None:
        """Re-encrypt the vault under a new passphrase. save() draws a fresh
        salt and nonce every time, so the entire envelope is rebuilt — the
        old passphrase can never open the new blob."""
        if not new_passphrase:
            raise VaultError("empty passphrase refused")
        self._passphrase = new_passphrase
        self.save()

    # ── lookups (the swappable interface) ───────────────────────────────
    @property
    def version(self) -> int:
        return int(self._p["vault_version"])

    def token_for(self, anytype_uuid: str) -> str | None:
        for e in self._p["entries"]:
            if e["anytype_uuid"] == anytype_uuid and e["status"] == "active":
                return e["token"]
        return None

    def resolve(self, token: str) -> str | None:
        for e in self._p["entries"]:
            if e["token"] == token and e["status"] == "active":
                return e["plaintext"]
        return None

    def active_plaintexts(self) -> dict[str, str]:
        """plaintext -> token, for the free-text lint."""
        return {e["plaintext"]: e["token"]
                for e in self._p["entries"] if e["status"] == "active"}

    def entries(self) -> list[dict]:
        return list(self._p["entries"])

    # ── minting (serialized to ONE authority; deliberate, never silent) ──
    def _draw(self, pool: str) -> str:
        entry = self._p["pools"].get(pool)
        if entry is None:
            raise VaultError(f"wordpool '{pool}' missing from this vault — "
                             f"run: vault_tool.py extend")
        avail = entry["available"]
        if not avail:
            raise VaultError(f"wordpool '{pool}' exhausted — extend the seed files")
        w = avail.pop(secrets.randbelow(len(avail)))   # random, not sequential
        self._p["pools"][pool]["used"].append(w)
        return w

    def mint(self, anytype_uuid: str, namespace: str, plaintext: str) -> str:
        if namespace not in NAMESPACES:
            raise VaultError(f"namespace must be one of {NAMESPACES}")
        existing = self.token_for(anytype_uuid)
        if existing:
            return existing
        taken = {e["token"] for e in self._p["entries"]}
        pool = {"proj": "proj", "org": "org", "manual": "manual",
                "contact": "contact", "tf": "tf", "domain": "domain"}.get(namespace)
        while True:
            if namespace == "person":
                # Stars (2026-08-10) > cartoons (2026-08-09) > adjective+animal.
                # Cartoons produced PIGPEN and PORKCHOP for colleagues; star and
                # constellation names read as codenames without reading as a joke.
                # This is a PREFERENCE, not a migration — tokens already minted
                # keep their name until explicitly retired and re-minted.
                if self._p["pools"].get("person_star", {}).get("available"):
                    token = self._draw("person_star").upper()
                elif self._p["pools"].get("person_char", {}).get("available") or \
                     self._p["pools"].get("person_char", {}).get("used"):
                    token = self._draw("person_char").upper()
                else:
                    token = f"{self._draw('person_adj').title()} {self._draw('person_noun').title()}"
            else:
                token = self._draw(pool).upper()
            # A drawn word is consumed even on collision (it can never be used),
            # so this terminates: pools are finite and shrink every draw.
            if token not in taken:
                break
        self._p["entries"].append({
            "anytype_uuid": anytype_uuid,
            "token": token,
            "namespace": namespace,
            "plaintext": plaintext,
            "status": "active",
            "minted_under_version": self.version,
        })
        self._p["vault_version"] = self.version + 1
        return token

    def extend_pools(self, pools_dir: Path) -> dict[str, int]:
        """Top up the vault's wordpools from the seed files.

        The pools are snapshotted into the vault at create() time, so growing
        wordpools/*.txt does nothing for an existing vault — a pool simply runs
        out ("wordpool 'proj' exhausted"). This adds seed words that are not
        already available or used, leaving every existing token untouched.
        """
        added = {}
        for ns, fname in POOL_FILES:
            path = pools_dir / fname
            if not path.is_file():
                continue
            words = [w.strip() for w in path.read_text(encoding="utf-8").splitlines()
                     if w.strip() and not w.startswith("#")]
            pool = self._p["pools"].setdefault(ns, {"available": [], "used": []})
            known = set(pool["available"]) | set(pool["used"])
            fresh = [w for w in dict.fromkeys(words) if w not in known]
            pool["available"].extend(fresh)
            added[ns] = len(fresh)
        if any(added.values()):
            self._p["vault_version"] = self.version + 1
        return added

    def pool_status(self) -> dict[str, tuple[int, int]]:
        return {ns: (len(p["available"]), len(p["used"]))
                for ns, p in self._p["pools"].items()}

    def repoint(self, new_uuid: str, plaintext: str, namespace: str = "proj") -> str | None:
        """Give a NEW object id the token an existing entry already holds.

        Needed when the same real entity is re-created as a new Anytype object
        (e.g. moving from a staging space to one space per project): the uuid
        changes, but the codename must not — otherwise the same project ends up
        with two codenames and every earlier report stops matching.

        Matches on the exact plaintext of an ACTIVE entry in the same namespace.
        Returns the reused token, or None when there is nothing to reuse (the
        caller should mint instead). Idempotent: a uuid that already resolves
        keeps its token.
        """
        already = self.token_for(new_uuid)
        if already:
            return already
        for e in self._p["entries"]:
            if (e["status"] == "active" and e["namespace"] == namespace
                    and e["plaintext"] == plaintext):
                self._p["entries"].append({
                    "anytype_uuid": new_uuid,
                    "token": e["token"],
                    "namespace": namespace,
                    "plaintext": plaintext,
                    "status": "active",
                    "minted_under_version": self.version,
                    "repointed_from": e["anytype_uuid"],
                })
                self._p["vault_version"] = self.version + 1
                return e["token"]
        return None

    def retire(self, token: str) -> bool:
        for e in self._p["entries"]:
            if e["token"] == token and e["status"] == "active":
                e["status"] = "retired"
                self._p["vault_version"] = self.version + 1
                return True
        return False
