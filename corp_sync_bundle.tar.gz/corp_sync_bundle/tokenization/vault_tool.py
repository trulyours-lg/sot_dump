#!/usr/bin/env python3
"""
vault_tool.py — curation CLI for the SOT tokenization vault.

Runs on the DEVELOPER WORKSTATION (the canonical vault source, handoff §8.7)
or the single designated mint operator's laptop. Minting is deliberate and
serialized to that one authority — never automatic, never concurrent.

    python vault_tool.py init                      # new vault from wordpools
    python vault_tool.py status                    # version, counts, pool levels
    python vault_tool.py mint                      # process the pending-mint queue
    python vault_tool.py mint --uuid U --ns proj --name "Real Name"
    python vault_tool.py list [--ns person]
    python vault_tool.py retire --token QUARTZ
    python vault_tool.py verify                    # signature + decrypt check
    python vault_tool.py rekey                     # change the vault passphrase
    python vault_tool.py extend                    # top wordpools up from
                                                   # wordpools/*.txt (fixes
                                                   # "wordpool exhausted")
    python vault_tool.py repoint                   # queue: reuse codenames for
                                                   # re-created objects (same
                                                   # name, new anytype uuid)
    python vault_tool.py repoint --uuid U --name "Real Name"

Passphrase: prompted (or SOTC_VAULT_PASSPHRASE for tests). The vault file
defaults to ./vault.blob next to this script; the pending queue
(./pending_mints.json) is written by sync_client.py when it meets unseen
Anytype uuids. Distribute the updated blob OUT-OF-BAND after curation —
never through the SOT/sync path.
"""

from __future__ import annotations

import argparse
import getpass
import json
import os
import sys
from pathlib import Path

from vault import Vault, VaultError, NAMESPACES

HERE = Path(__file__).parent
DEFAULT_VAULT = HERE / "vault.blob"
QUEUE = HERE / "pending_mints.json"


def passphrase(confirm: bool = False) -> str:
    pw = os.environ.get("SOTC_VAULT_PASSPHRASE")
    if pw:
        return pw
    pw = getpass.getpass("vault passphrase: ")
    if confirm:
        if getpass.getpass("confirm passphrase: ") != pw:
            raise SystemExit("passphrases do not match")
    if not pw:
        raise SystemExit("empty passphrase refused")
    return pw


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")

    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["init", "status", "mint", "list", "retire", "verify",
                                    "rekey", "repoint", "extend"])
    ap.add_argument("--vault", default=str(DEFAULT_VAULT))
    ap.add_argument("--uuid")
    ap.add_argument("--ns", choices=list(NAMESPACES))
    ap.add_argument("--name")
    ap.add_argument("--token")
    args = ap.parse_args()
    vpath = Path(args.vault)

    if args.cmd == "init":
        v = Vault.create(vpath, passphrase(confirm=True), HERE / "wordpools")
        print(f"created {vpath} at vault_version {v.version}")
        return 0

    v = Vault.open(vpath, passphrase())

    if args.cmd == "verify":
        print(f"OK — signature valid, decrypts, vault_version {v.version}, "
              f"{len(v.entries())} entries")
        return 0

    if args.cmd == "rekey":
        # New passphrase is prompted directly (never SOTC_VAULT_PASSPHRASE —
        # that env var, if set, holds the OLD one used to open above).
        new = getpass.getpass("NEW passphrase: ")
        if getpass.getpass("confirm NEW passphrase: ") != new:
            raise SystemExit("passphrases do not match")
        if not new:
            raise SystemExit("empty passphrase refused")
        v.rekey(new)
        print(f"rekeyed {vpath} — old passphrase is now useless "
              f"(vault_version {v.version}, {len(v.entries())} entries intact)")
        return 0

    if args.cmd == "status":
        active = sum(1 for e in v.entries() if e["status"] == "active")
        retired = len(v.entries()) - active
        print(f"vault_version: {v.version}")
        print(f"entries: {active} active, {retired} retired")
        for ns, pool in v._p["pools"].items():  # noqa: SLF001 (curation tool)
            print(f"pool {ns}: {len(pool['available'])} available, {len(pool['used'])} used")
        if QUEUE.is_file():
            q = json.loads(QUEUE.read_text(encoding="utf-8"))
            print(f"pending mint queue: {len(q)} item(s) — run: vault_tool.py mint")
        return 0

    if args.cmd == "list":
        for e in v.entries():
            if args.ns and e["namespace"] != args.ns:
                continue
            print(f"[{e['status']:7s}] {e['namespace']:6s} {e['token']:24s} "
                  f"= {e['plaintext']}  ({e['anytype_uuid']})")
        return 0

    if args.cmd == "retire":
        if not args.token:
            raise SystemExit("--token required")
        if v.retire(args.token):
            v.save()
            print(f"retired {args.token}; vault_version now {v.version}. "
                  f"Distribute the updated blob out-of-band.")
        else:
            print(f"no active entry for token {args.token}")
        return 0

    # ── extend: top the wordpools up from the seed files ─────────────────
    if args.cmd == "extend":
        before = v.pool_status()
        added = v.extend_pools(HERE / "wordpools")
        if any(added.values()):
            v.save()
        after = v.pool_status()
        for ns in sorted(after):
            a_av, a_us = after[ns]
            print(f"  {ns:12} +{added.get(ns,0):3d} new · {a_av} available, {a_us} used")
        print(f"\nvault_version {v.version}. Distribute the updated blob out-of-band.")
        return 0

    # ── repoint: same entity, new object id — keep the codename ──────────
    if args.cmd == "repoint":
        if args.uuid:
            if not args.name:
                raise SystemExit("--uuid needs --name (the exact plaintext to match)")
            tok = v.repoint(args.uuid, args.name, args.ns or "proj")
            if tok:
                v.save(); print(f"{args.name!r} -> reuses {tok}  (vault_version {v.version})")
            else:
                print(f"no active entry named {args.name!r} — nothing to reuse; mint instead")
            return 0
        if not QUEUE.is_file():
            print("no pending_mints.json — nothing queued by the sync.")
            return 0
        queue = json.loads(QUEUE.read_text(encoding="utf-8"))
        if not queue:
            print("mint queue is empty.")
            return 0
        reused, left = 0, []
        for item in queue:
            tok = v.repoint(item["anytype_uuid"], item["plaintext"], item.get("namespace", "proj"))
            if tok:
                print(f"  reuse {tok:16} <- {item['plaintext'][:52]}")
                reused += 1
            else:
                left.append(item)
        if reused:
            v.save()
        QUEUE.write_text(json.dumps(left, indent=1), encoding="utf-8")
        print(f"\nrepointed {reused} entit(y/ies) to their existing codenames; "
              f"{len(left)} genuinely new still queued -> run: vault_tool.py mint")
        print(f"vault_version {v.version}. Distribute the updated blob out-of-band.")
        return 0

    # ── mint: single item or the queue, always deliberate ────────────────
    if args.uuid:
        if not (args.ns and args.name):
            raise SystemExit("--uuid needs --ns and --name")
        tok = v.mint(args.uuid, args.ns, args.name)
        v.save()
        print(f"{args.name!r} -> {tok}  (vault_version {v.version})")
        return 0

    if not QUEUE.is_file():
        print("no pending_mints.json — nothing queued by the sync.")
        return 0
    queue = json.loads(QUEUE.read_text(encoding="utf-8"))
    if not queue:
        print("mint queue is empty.")
        return 0
    print(f"{len(queue)} queued item(s). y = mint, s = skip (stays queued), "
          f"d = drop (never tokenize):")
    remaining = []
    for item in queue:
        ans = input(f"  [{item['namespace']}] {item['plaintext']!r} "
                    f"({item['anytype_uuid']}) — mint? [y/s/d] ").strip().lower()
        if ans == "y":
            tok = v.mint(item["anytype_uuid"], item["namespace"], item["plaintext"])
            print(f"    -> {tok}")
        elif ans == "d":
            print("    dropped")
        else:
            remaining.append(item)
    v.save()
    QUEUE.write_text(json.dumps(remaining, indent=1), encoding="utf-8")
    print(f"done. vault_version {v.version}; {len(remaining)} still queued. "
          f"Distribute the updated blob out-of-band.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except VaultError as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)
