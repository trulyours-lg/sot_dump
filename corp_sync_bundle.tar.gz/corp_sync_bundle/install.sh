#!/bin/sh
# SOT sync daemon — offline install from bundled wheels. No network needed.
# Creates a private venv so Debian's externally-managed-environment rule
# (PEP 668) is never an issue.
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
./.venv/bin/pip install --no-index --find-links wheels/ requests pyyaml cryptography
echo
echo "Installed. Run everything with ./.venv/bin/python — see README_CORP.md"
