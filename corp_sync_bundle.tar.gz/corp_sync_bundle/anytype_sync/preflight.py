#!/usr/bin/env python3
"""
preflight.py — "is anything about to be lost, misfiled, or silently withheld?"

READ-ONLY. Run it before and after any sync change, after importing projects
into Anytype, after adding a Task Force, and whenever SOT's project count looks
wrong. It answers the one question the admin actually has:

    is every Anytype project going to arrive in SOT, in the right Task Force,
    with a stable codename — and is anything in SOT now orphaned?

    python preflight.py                 # check everything, print a verdict
    python preflight.py --quiet         # only problems

Exit: 0 = clean (or warnings only), 1 = something WILL go wrong, 2 = could not
run the checks (Anytype down, DB unreachable).

WHY THIS EXISTS. Nothing here is hypothetical: every check below is a failure
that actually happened between 2026-08-04 and 2026-08-06 and cost real time.
A project is almost never LOST — the sync never deletes and never overwrites an
id — it is INVISIBLE, and each kind of invisibility looks identical from the
app: a project that simply isn't there.

Reads Anytype over loopback, sync.yml, the vault (version only — no
passphrase), and the SOT database directly. It is an ADMIN-side tool: unlike
sync_client.py, which never speaks SQL, this one reads the DB because half the
question ("is SOT holding ghosts?") only exists there.

Env: SOT_DB_NAME (default sot_research_2026), SOT_DB_USER (default postgres),
     SOT_DB_PASSWORD; ANYTYPE_API_TOKEN or keyring sotc/anytype_api_token.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import requests
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from sync_client import Anytype, get_secret, obj_name, prop_labels, prop_text  # noqa: E402

HERE = Path(__file__).resolve().parent
OK, WARN, FAIL = "OK", "WARN", "FAIL"
results: list[tuple[str, str, str, list[str]]] = []


def record(level, title, detail, items=None):
    results.append((level, title, detail, items or []))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default=str(HERE / "sync.yml"))
    ap.add_argument("--quiet", action="store_true", help="print only WARN/FAIL")
    args = ap.parse_args()

    for s in (sys.stdout, sys.stderr):
        if hasattr(s, "reconfigure"):
            s.reconfigure(encoding="utf-8", errors="replace")

    cfg_path = Path(args.config)
    if not cfg_path.is_file():
        print(f"{cfg_path} not found.", file=sys.stderr)
        return 2
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
    spaces = cfg.get("spaces") or []
    aliases = {str(k).strip().lower(): str(v) for k, v in (cfg.get("tf_aliases") or {}).items()}

    try:
        at = Anytype(get_secret("anytype_api_token", "ANYTYPE_API_TOKEN"))
        live_spaces = at._paged(lambda off: at._get("/v1/spaces", {"offset": off, "limit": 100}))
    except Exception as e:  # noqa: BLE001
        print(f"cannot reach Anytype ({e}) — start the Anytype app and retry.", file=sys.stderr)
        return 2

    try:
        import psycopg2
        cn = psycopg2.connect(
            host=os.environ.get("SOT_DB_HOST", "127.0.0.1"),
            dbname=os.environ.get("SOT_DB_NAME", "sot_research_2026"),
            user=os.environ.get("SOT_DB_USER", "postgres"),
            password=os.environ.get("SOT_DB_PASSWORD", ""))
        cur = cn.cursor()
    except Exception as e:  # noqa: BLE001
        print(f"cannot reach the SOT database ({e}) — set SOT_DB_PASSWORD.", file=sys.stderr)
        return 2

    configured = {str(s["space_id"]) for s in spaces}
    # Spaces excluded ON PURPOSE (the retired collector, directories, archives).
    # Declared in sync.yml so "invisible" is always a recorded decision rather
    # than an oversight this check has to re-litigate every run.
    ignored = {str(x) for x in (cfg.get("ignore_spaces") or [])}

    # ── 1. Anytype spaces the sync never even looks at ───────────────────
    # A space missing from sync.yml is not synced, not warned about, and not
    # visible anywhere: the sync only iterates what sync.yml lists.
    unlisted = []
    for s in live_spaces:
        if s["id"] in configured or s["id"] in ignored or (s.get("name") or "") in ignored:
            continue
        try:
            r = at._post(f"/v1/spaces/{s['id']}/search", {"types": ["project"]}, {"limit": 50})
            n = len([o for o in r.get("data", []) if not o.get("archived")])
        except Exception:  # noqa: BLE001
            n = 0
        if n:
            unlisted.append(f"{s.get('name', '?')[:44]} — {n} project(s)")
    record(FAIL if unlisted else OK,
           "Every Anytype space with projects is in sync.yml",
           f"{len(configured)} configured / {len(live_spaces)} live"
           + (f" / {len(ignored)} ignored by choice" if ignored else "")
           + (" — spaces below are INVISIBLE to the sync; re-run "
              "anytype_tools/build_sync_yml.py --write" if unlisted else ""),
           unlisted)

    # ── 2. objects typed `page` instead of `project` ─────────────────────
    # The sync searches types=["project"]. A project authored as a page (easy
    # to do in the Anytype UI) is skipped in silence — this is exactly how
    # "LG work" went missing while its space was configured correctly.
    mistyped, seen_ids, tag_counts, untagged = [], set(), {}, []
    for sp in spaces:
        sid = str(sp["space_id"])
        try:
            projects = [o for o in at.objects_of_type(sid, "project") if not o.get("archived")]
        except Exception:  # noqa: BLE001
            continue
        if not projects:
            try:
                objs = at._paged(lambda off, s=sid: at._get(
                    f"/v1/spaces/{s}/objects", {"offset": off, "limit": 100}))
            except Exception:  # noqa: BLE001
                objs = []
            pages = [o for o in objs
                     if (o.get("type") or {}).get("key") == "page" and not o.get("archived")]
            if pages:
                mistyped.append(f"{sp.get('name', sid)[:44]} — page: "
                                f"{(pages[0].get('name') or '?')[:34]!r}")
            continue
        for stub in projects:
            seen_ids.add(stub["id"])
            o = at.object_detail(sid, stub["id"])
            labels = prop_labels(o, "Primary Task Force") or prop_labels(o, "Task Force")
            if labels:
                tag_counts[labels[0]] = tag_counts.get(labels[0], 0) + 1
            else:
                untagged.append(f"{(obj_name(o) or '?')[:44]} ({sp.get('name', '')[:24]})")

    record(FAIL if mistyped else OK,
           "Every project object is typed `project`, not `page`",
           f"{len(seen_ids)} project objects readable"
           + (" — the spaces below hold a page where a project belongs; change "
              "its type in Anytype (Object menu → change type)" if mistyped else ""),
           mistyped)

    # ── 3. Task Force tags that resolve ──────────────────────────────────
    unmapped = [f"{t} — {n} project(s)" for t, n in sorted(tag_counts.items())
                if t.strip().lower() not in aliases]
    record(WARN if unmapped else OK,
           "Every Anytype Task Force tag maps to a SOT task force",
           f"{len(tag_counts)} tag(s) in use, {len(aliases)} alias(es) configured"
           + (" — tags below fall back to the space default, so those projects "
              "land in the WRONG task force (not lost). Add them to tf_aliases."
              if unmapped else ""),
           unmapped)

    # ── 4. aliases pointing at task forces that no longer exist ──────────
    cur.execute("SELECT id::text, name FROM problem_areas")
    pa_by_id = {i: n for i, n in cur.fetchall()}
    broken = [f"{t} -> {u}" for t, u in aliases.items() if u not in pa_by_id]
    record(FAIL if broken else OK,
           "Every tf_aliases target exists in SOT",
           f"{len(aliases)} alias(es)"
           + (" — a deleted/renamed task force uuid; regenerate the map by name"
              if broken else ""),
           broken)

    # ── 5. submit rights cover every task force in play ──────────────────
    # RLS checks the row ALREADY STORED on UPDATE, so one ungranted TF kills
    # the WHOLE atomic push — including every unrelated project in the batch.
    cur.execute("""SELECT DISTINCT r.problem_area_id::text
                     FROM tf_submit_rights r JOIN users u ON u.id = r.user_id
                    WHERE u.email = %s""",
                (os.environ.get("SOT_SYNC_ACCOUNT", "test.alpha@sotc.test"),))
    granted = {r[0] for r in cur.fetchall()}
    need = set(aliases.values()) | {str(s["problem_area_id"]) for s in spaces}
    cur.execute("SELECT DISTINCT problem_area_id::text FROM projects WHERE problem_area_id IS NOT NULL")
    need |= {r[0] for r in cur.fetchall()}
    missing = sorted(pa_by_id.get(u, u) for u in need - granted)
    record(FAIL if missing else OK,
           "The sync account may submit to every task force in play",
           f"{len(granted)}/{len(pa_by_id)} granted"
           + (" — the WHOLE push dies (atomic) while any of these is ungranted"
              if missing else ""),
           missing)

    # ── 6. names the sync is withholding until they are minted ───────────
    queue = HERE.parent / "tokenization" / "pending_mints.json"
    pending = json.loads(queue.read_text(encoding="utf-8")) if queue.is_file() else []
    record(WARN if pending else OK,
           "No project is being withheld for minting",
           f"{len(pending)} queued"
           + (" — held back on purpose (never sent as plaintext). Run "
              "tokenization/vault_tool.py mint, redistribute the vault, re-sync."
              if pending else ""),
           [])

    # ── 7. SOT rows whose Anytype object is gone ─────────────────────────
    # Deletions never propagate — by design, so a bad sync cannot wipe SOT.
    # The cost is ghosts: rows for objects archived or deleted upstream.
    cur.execute("SELECT name, anytype_object_id FROM projects WHERE anytype_object_id IS NOT NULL")
    ghosts = [f"{n} ({oid[:24]}…)" for n, oid in cur.fetchall() if oid not in seen_ids]
    record(WARN if ghosts else OK,
           "No orphaned projects in SOT",
           f"{len(ghosts)} row(s) whose Anytype object is archived/deleted/unreadable"
           + (" — kept deliberately (the sync never deletes); retire them by hand "
              "if they are really gone" if ghosts else ""),
           ghosts[:12])

    # ── 8. hand-made SOT rows that no sync will ever maintain ────────────
    cur.execute("SELECT count(*) FROM projects WHERE anytype_object_id IS NULL")
    unlinked = cur.fetchone()[0]
    record(WARN if unlinked else OK,
           "Every SOT project is linked to an Anytype object",
           f"{unlinked} unlinked row(s)"
           + (" — created outside the sync; they will never update and cannot "
              "be written back" if unlinked else ""),
           [])

    # ── 9. vault skew: can readers actually reveal what SOT holds? ───────
    # The vault's version is INSIDE the encrypted payload, so a read-only check
    # cannot compare it without the passphrase — and this tool must never ask
    # for one. State what SOT expects and let the custodian confirm.
    cur.execute("SELECT max(vault_version) FROM projects")
    db_version = cur.fetchone()[0]
    record(OK, "Vault version required by readers",
           f"SOT rows are stamped v{db_version} — every distributed vault copy "
           f"must be v{db_version} or newer, or those codenames cannot be revealed",
           [])

    # ── 10. projects relying on the space fallback ───────────────────────
    record(WARN if untagged else OK,
           "Every project carries its own Task Force tag",
           f"{len(untagged)} untagged"
           + (" — these inherit the space's fallback TF, which a sync.yml "
              "regeneration can silently change. Tag them in Anytype."
              if untagged else ""),
           untagged[:12])

    # ── verdict ──────────────────────────────────────────────────────────
    cur.execute("SELECT count(*) FROM projects")
    sot_n = cur.fetchone()[0]
    cur.close(); cn.close()

    width = 72
    print("=" * width)
    print(f"SYNC PREFLIGHT — Anytype {len(seen_ids)} project objects · SOT {sot_n} rows")
    print("=" * width)
    for level, title, detail, items in results:
        if args.quiet and level == OK:
            continue
        mark = {OK: "  ok ", WARN: " WARN", FAIL: " FAIL"}[level]
        print(f"{mark}  {title}\n        {detail}")
        for i in items:
            print(f"          - {i}")
    fails = sum(1 for r in results if r[0] == FAIL)
    warns = sum(1 for r in results if r[0] == WARN)
    print("-" * width)
    if fails:
        print(f"RESULT: {fails} FAIL, {warns} WARN — fix the FAILs before the next push.")
        return 1
    print(f"RESULT: clean{f' ({warns} warning(s))' if warns else ''} — "
          f"every Anytype project will reach SOT in the right task force.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
