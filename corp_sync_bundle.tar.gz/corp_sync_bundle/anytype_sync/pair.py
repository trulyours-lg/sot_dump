#!/usr/bin/env python3
"""pair.py — get an Anytype local-API token and store it for sync_client.

Anytype issues API keys through an in-app pairing: this asks Anytype to show
a 4-digit code, you type it here, and it exchanges it for a key and saves it
to the OS keyring (sotc / anytype_api_token) — where sync_client reads it.

Prereq: the Anytype desktop app is OPEN. Run:  python pair.py
"""
from __future__ import annotations
import os, sys, requests

BASE = os.environ.get("ANYTYPE_API_BASE", "http://127.0.0.1:31009")
VER = "2025-05-20"
H = {"Anytype-Version": VER, "Content-Type": "application/json"}


def main() -> int:
    try:
        r = requests.post(f"{BASE}/v1/auth/challenges",
                          json={"app_name": "SOT sync"}, headers=H, timeout=8)
    except requests.RequestException as e:
        print(f"Can't reach Anytype at {BASE} — is the desktop app open? ({e})")
        return 1
    if r.status_code not in (200, 201):
        print(f"Anytype refused the pairing request [{r.status_code}]: {r.text[:200]}")
        return 1
    challenge_id = r.json()["challenge_id"]
    print("A 4-digit code is now showing in your Anytype app.")
    code = input("Enter the 4-digit code: ").strip()

    r = requests.post(f"{BASE}/v1/auth/api_keys",
                      json={"challenge_id": challenge_id, "code": code}, headers=H, timeout=8)
    if r.status_code not in (200, 201) or not r.json().get("api_key"):
        print(f"Pairing failed [{r.status_code}]: {r.text[:200]}  (codes are single-use — re-run to retry)")
        return 1
    key = r.json()["api_key"]

    try:
        import keyring
        keyring.set_password("sotc", "anytype_api_token", key)
        print("Success — token stored in the OS keyring (sotc / anytype_api_token).")
        print("sync_client will pick it up automatically. You can now run --dry-run.")
    except Exception as e:  # noqa: BLE001
        print(f"Paired OK, but keyring is unavailable ({e}).")
        print("Set this in your shell instead (keep it secret):")
        print(f'  ANYTYPE_API_TOKEN={key}')
    return 0


if __name__ == "__main__":
    sys.exit(main())
