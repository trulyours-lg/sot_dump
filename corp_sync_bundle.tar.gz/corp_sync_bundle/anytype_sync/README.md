# Anytype → SOT-v3 sync (distributed, per-lead)

> **⚠ Topology note (updated 2026-07-28):** where this doc describes a *per-lead / local-Anytype* sync, that was **superseded** — the current model is **one VM running Docker containers** (Anytype, the SOT app, PostgreSQL, and the sync + vault) on a whole-host-encrypted internal Secure Server, with identity via **Xray UUID → Zitadel token → 6-digit PIN** (no mTLS). One central sync runs intra-VM. Authoritative: [`../docs/DEPLOYMENT_TOPOLOGY.md`](../docs/DEPLOYMENT_TOPOLOGY.md) and [`../docs/DEPLOY_IDENTITY.md`](../docs/DEPLOY_IDENTITY.md). The tokenization-crypto and intake substance below still stands.

REWRITTEN 2026-07-22 for SOT-v3, updated 2026-07-28 for the single-VM model.
The oldest design (a shared "SOT Sync" identity invited into every space,
writing directly to a local Postgres) is retired: the sync now reads Anytype
over loopback and POSTs codenames to the SOT app over HTTP with a Bearer
token. In production that is **one central sync running intra-VM** (see
[`../docs/DEPLOYMENT_TOPOLOGY.md`](../docs/DEPLOYMENT_TOPOLOGY.md)); the same
`sync_client.py` also runs on a single dev machine. The old `sync.py`
remains for reference only; **the tool is `sync_client.py`**.

## The model

- **27 per-Task-Force Anytype spaces.** The TF template holds Project and
  Task types only. A space IS one TF; there is no "Task Force" select and
  there are no domain spaces. Domains exist only inside SOT.
- **One central sync in production.** The Anytype spaces are readable in the
  Anytype container and **one** sync job runs intra-VM (container to
  container) under a single sync service account (see
  [`../docs/DEPLOYMENT_TOPOLOGY.md`](../docs/DEPLOYMENT_TOPOLOGY.md)). The same
  `sync_client.py` runs per-machine for a single-machine **dev** setup — the
  mechanics below are identical either way.
- **The sync never speaks SQL.** The client POSTs to the server's
  `/api/sync` over HTTPS (host-wide Caddy terminates TLS; the app never
  handles certs — identity is the host-injected Zitadel identity, see
  [`../docs/DEPLOY_IDENTITY.md`](../docs/DEPLOY_IDENTITY.md)), carrying a
  personal **Bearer token** for the write path. The server checks per-TF
  submit rights — one wrong TF rejects the whole batch — validates the
  payload shape, and upserts under the same row-level security readers face.
- **Idempotent & non-destructive.** Everything keys on `anytypeObjectId`;
  re-running replaces, never duplicates; deletions in Anytype never
  propagate. Anytype stays the source of truth for synced rows.
- Wins are NOT synced — they are recorded manually in the SOT app (Q4
  decision). Update objects are not part of the v3 template.

## Space template contract (properties matched by name, case-insensitive)

| Type    | Properties read |
|---------|-----------------|
| Project | Name, Description, Status, Priority, Owner, Start Date, Due Date, Latest Update |
| Task    | Name, Status, Priority, Assignee, Due Date, Parent Project |

Canonical selects — Status: `Not Started, In Progress, Blocked, On Hold,
Done, Cancelled` · Priority: `Critical, High, Medium, Low`. Unknown values
fall back with a warning in the push result (never a silent drop).
Owner/Assignee are matched against SOT users by full name; misses are
warnings.

## Per-lead setup (once)

```
pip install requests keyring pyyaml
keyring set sotc api_token           # personal SOT token (admin shows once)
keyring set sotc anytype_api_token   # your Anytype: Settings → API → pair app
```

`sync.yml` next to sync_client.py (the admin generates yours):

```yaml
server: https://<sot-v3-server>
# no client cert: host-wide Caddy terminates TLS and the host injects the
# Zitadel identity; the sync authenticates with its Bearer token (keyring).

# Task Force resolution (2026-08-05). Anytype is the author of record: a
# project's own "Primary Task Force" tag decides its SOT task force, and each
# space's problem_area_id is only the FALLBACK. Before this, the fallback was
# the sole source — which parked 47 of 59 spaces under "Research hub" whatever
# their real TF said.
tf_aliases:                             # Anytype tag  -> problem_areas.id
  "Research":       "<TF uuid>"         # matched case-insensitively
  "Tech Policy":    "<TF uuid>"

spaces:
  - space_id: "<anytype space id>"      # Anytype: Settings → Space → Space ID
    problem_area_id: "<TF uuid>"        # fallback only — from your admin sheet
    name: "Media hub"
```

**Partners** move in both directions each cycle:

- **Anytype → SOT** — Category, Status and Skills are read and mapped to SOT's
  `ref_partner_*` codes (`POST /api/partners_sync`, admin token). An unknown
  label is a warning, never a guess; an unknown SOT ID is reported, never
  created (the workbook loader owns the id space and the vault mints).
  Availability notes are never read — free text stays in Anytype.
- **SOT → Anytype** — the Partners view queues Category/Status changes; this
  client drains the queue, compare-and-sets, PATCHes the select, and acks.
  Needs the `can_edit_projects` permission plus partners access.
  Two quirks of the live API this leg handles: a partner's select options may
  not exist yet (they are created from SOT's closed vocabulary), and a space
  can hold several properties with the same name AND key — the object's TYPE is
  the only authority on which one it means.

SOT's task-force names were aligned to Anytype's tag vocabulary on 2026-08-06,
so this map is a straight **1:1 by name** — regenerate it by name match after
adding a task force. (A `tf_overrides` key, keyed by project name, existed while
one Anytype tag had to be split across two differently-named SOT task forces;
it is gone now that both vocabularies agree, and re-adding it would only fight
the taxonomy.) An unmapped tag is never silently wrong — the sync prints
`! <project>: tag '<x>' — falling back to sync.yml`.

**The sync account needs submit rights for EVERY task force it may write** —
one central sync, all TFs (`tf_submit_rights`). Miss one and the push dies with
`new row violates row-level security policy (USING expression) for table
"projects"` the moment a project moves into the ungranted TF: RLS checks the
row ALREADY STORED, not just the new values, so an unwritable current TF blocks
the update. Grant first, then re-sync.

**A project with no TF tag at all** also falls back. Two exist today
(`LG work — SOT/Anytype workflow`, `Fence Sitter Prodding`); tagging them in
Anytype is better than relying on the fallback.

## Running

```
python sync_client.py --dry-run    # print the exact payload, send nothing
python sync_client.py --push      # send it
```

- Anytype not running → exit 2, nothing sent.
- A TF you lack submit rights for → the server rejects the WHOLE push
  (403) and writes nothing.
- Schedule weekly if you like (Task Scheduler); a missed run self-heals —
  the next push carries everything current.

## Local testing without Anytype/production

`deploy/staging/` is a **legacy** local TLS harness (the old mTLS path — the
production identity path is now Xray → Zitadel, see
[`../docs/DEPLOY_IDENTITY.md`](../docs/DEPLOY_IDENTITY.md) and STAGING.md),
and `mock_anytype.py` (same API shape, fixture data) lets the whole
pipeline run with zero real data — exactly how the Step-3 acceptance ran.
NOTE: the mock encodes our model of the Anytype API; one live --dry-run
against a throwaway space (pilot, first act) still validates the real
contract.
