#!/usr/bin/env python3
"""
sync_client.py — SOT-v3 per-lead sync: YOUR local Anytype → the Secure Server.

Runs on the LEAD'S OWN machine. Reads the Task Force spaces listed in
sync.yml from your local Anytype API (loopback only), builds a typed
projects/tasks payload per TF, and pushes it over HTTPS to POST /api/sync
with your personal API token. The server checks your per-TF submit rights
(one wrong TF rejects the whole batch), validates the payload shape, and
upserts idempotently — re-running is always safe, deletions never
propagate, Anytype stays the source of truth.

    python sync_client.py --dry-run     # print the exact payload, send nothing
    python sync_client.py --push        # send it

Secrets (OS keychain only, never in files):
    keyring set sotc api_token           # your SOT token (admin shows it once)
    keyring set sotc anytype_api_token   # your Anytype local API token

mTLS: when the server requires client certificates, pass
    --cert path\\to\\device.pem --key path\\to\\device.key
(or set cert/key in sync.yml). Your browser uses the same certificate.

Config (sync.yml next to this file; the admin generates yours):
    server: https://sot.internal.example
    # cert: C:\\certs\\me.pem        # optional here instead of --cert
    # key:  C:\\certs\\me.key
    tf_aliases:                      # Anytype TF tag -> problem_areas.id
      "Research": "<TF uuid>"        #   (see resolve_tf; case-insensitive)
    tf_overrides:                    # project NAME -> problem_areas.id, for
      "Some Project": "<TF uuid>"    #   tags coarser than SOT's taxonomy
    partners_space_id: "<space id>" # partners both ways (0040); omit to skip
    spaces:
      - space_id: "<anytype space id>"
        problem_area_id: "<TF uuid>" # FALLBACK only — the object's tag wins
        name: "Media hub"            # label for output only

Deps: pip install requests keyring pyyaml
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import pathlib
from pathlib import Path

import requests
import yaml

# The vault lives in ../tokenization; import it only when tokenization is on
# so the sync runs without the tokenization package present.
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent / "tokenization"))

KEYRING_SERVICE = "sotc"
ANYTYPE_BASE = os.environ.get("ANYTYPE_API_BASE", "http://127.0.0.1:31009")
ANYTYPE_VERSION = "2025-05-20"
PAGE_LIMIT = 100


def get_secret(entry: str, env_var: str) -> str:
    val = os.environ.get(env_var)
    if val:
        return val
    try:
        import keyring
        val = keyring.get_password(KEYRING_SERVICE, entry)
    except Exception as e:  # noqa: BLE001
        raise SystemExit(f"keyring unavailable ({e}); set {env_var} instead") from e
    if not val:
        raise SystemExit(
            f"No secret found. Run:  keyring set {KEYRING_SERVICE} {entry}\n"
            f"or set the {env_var} environment variable."
        )
    return val


# ── Anytype local API (loopback; the lead's own instance) ────────────────────
class Anytype:
    def __init__(self, token: str):
        self.s = requests.Session()
        self.s.headers.update({
            "Authorization": f"Bearer {token}",
            "Anytype-Version": ANYTYPE_VERSION,
            "Content-Type": "application/json",
        })

    def _get(self, path, params=None):
        r = self.s.get(f"{ANYTYPE_BASE}{path}", params=params or {}, timeout=30)
        r.raise_for_status()
        return r.json()

    def _post(self, path, body, params=None):
        r = self.s.post(f"{ANYTYPE_BASE}{path}", json=body, params=params or {}, timeout=30)
        r.raise_for_status()
        return r.json()

    def _paged(self, fetch):
        out, offset = [], 0
        while True:
            js = fetch(offset)
            data = js.get("data", [])
            out.extend(data)
            if not js.get("pagination", {}).get("has_more") or not data:
                return out
            offset += len(data)

    def objects_of_type(self, space_id, type_key):
        # Anytype's search matches the type KEY (e.g. "project"/"task"), NOT
        # the display name — passing "Project" returns 0 (verified against the
        # live 0.55 API, 2026-07-23). The fallback lists everything and filters
        # on either key or name, case-insensitively.
        def fetch(off):
            return self._post(f"/v1/spaces/{space_id}/search",
                              {"types": [type_key]},
                              {"offset": off, "limit": PAGE_LIMIT})
        res = self._paged(fetch)
        if res:
            return res
        objs = self._paged(lambda off: self._get(
            f"/v1/spaces/{space_id}/objects", {"offset": off, "limit": PAGE_LIMIT}))
        want = type_key.lower()
        return [o for o in objs
                if (o.get("type") or {}).get("key", "").lower() == want
                or (o.get("type") or {}).get("name", "").lower() == want]

    def object_detail(self, space_id, object_id):
        js = self._get(f"/v1/spaces/{space_id}/objects/{object_id}")
        return js.get("object", js)

    def patch_object(self, space_id, object_id, properties):
        """PATCH one object's properties — the write-back call. Verified on live
        0.55: PATCH /v1/spaces/{s}/objects/{o} returns 200."""
        r = self.s.patch(f"{ANYTYPE_BASE}/v1/spaces/{space_id}/objects/{object_id}",
                         json={"properties": properties}, timeout=30)
        if r.status_code not in (200, 201):
            raise RuntimeError(f"PATCH {r.status_code}: {r.text[:200]}")
        return r.json()

    def select_option_id(self, space_id, prop_key, labels):
        """Resolve a select label to its OPTION ID — the live 0.55 PATCH wants
        the tag id in `select`, not the label ("invalid select option ... Low").
        Tries each candidate label in order; cached per (space, property)."""
        cache = getattr(self, "_tag_cache", None)
        if cache is None:
            cache = self._tag_cache = {}
        ck = (space_id, prop_key)
        if ck not in cache:
            # the tags endpoint addresses the property by ID, not by key
            pid = None
            try:
                for p in self._get(f"/v1/spaces/{space_id}/properties",
                                   {"limit": 300}).get("data", []):
                    if (p.get("key") or "") == prop_key:
                        pid = p.get("id") or p.get("key")
                        break
            except requests.HTTPError:
                pass
            try:
                js = self._get(f"/v1/spaces/{space_id}/properties/{pid or prop_key}/tags",
                               {"limit": 100})
                cache[ck] = {(t.get("name") or "").strip().lower(): t.get("id")
                             for t in js.get("data", [])}
            except requests.HTTPError:
                cache[ck] = {}
        by_name = cache[ck]
        for lab in labels:
            hit = by_name.get(str(lab).strip().lower())
            if hit:
                return hit, lab
        return None, None

    def type_prop(self, space_id, type_key, name):
        """(property id, key) for a property AS DECLARED BY AN OBJECT TYPE.

        A space can hold SEVERAL properties with the same name AND the same key
        — the partners space has two called "Status", both keyed `status`: the
        built-in task one (options To Do/In Progress/Done/Active) and the
        Partner type's own (no options). Resolving by key from the space-wide
        list picks whichever comes first, and PATCHing an option id belonging to
        the other one fails with "invalid select option" (2026-08-05). The type
        is the only authority on which property an object of that type means.
        """
        cache = getattr(self, "_type_prop_cache", None)
        if cache is None:
            cache = self._type_prop_cache = {}
        ck = (space_id, type_key)
        if ck not in cache:
            props = {}
            try:
                for t in self._get(f"/v1/spaces/{space_id}/types", {"limit": 200}).get("data", []):
                    if (t.get("key") or "").lower() != type_key.lower():
                        continue
                    det = self._get(f"/v1/spaces/{space_id}/types/{t['id']}")
                    det = det.get("type", det)
                    for p in det.get("properties") or []:
                        # names can carry stray whitespace/tabs from the GUI
                        props[(p.get("name") or "").strip().lower()] = (p.get("id"), p.get("key"))
                    break
            except requests.HTTPError:
                pass
            cache[ck] = props
        return cache[ck].get(str(name).strip().lower(), (None, None))

    def ensure_select_option(self, space_id, prop_id, prop_key, label):
        """Resolve a select option id, CREATING the option when it is absent.

        The PARTNER leg only. partner_upload.py created the Partner objects with
        Category/Status as select properties carrying ZERO options (verified
        2026-08-05), so a read-only lookup can never write the first value. The
        labels come from SOT's ref_partner_* tables — a closed vocabulary — so
        creating one is safe.

        The project leg deliberately does NOT do this: Anytype's status/priority
        options already exist there, and inventing one would paper over a
        mapping bug instead of reporting it.
        """
        if not prop_id:
            return None
        try:
            js = self._get(f"/v1/spaces/{space_id}/properties/{prop_id}/tags", {"limit": 100})
            for tag in js.get("data", []):
                if (tag.get("name") or "").strip().lower() == str(label).strip().lower():
                    return tag.get("id")
        except requests.HTTPError:
            pass
        r = self.s.post(f"{ANYTYPE_BASE}/v1/spaces/{space_id}/properties/{prop_id}/tags",
                        json={"name": label, "color": "grey"}, timeout=30)
        if r.status_code not in (200, 201):
            raise RuntimeError(f"create option {label!r}: {r.status_code} {r.text[:120]}")
        getattr(self, "_tag_cache", {}).pop((space_id, prop_key), None)
        return ((r.json() or {}).get("tag") or {}).get("id")

    def space_prop_key(self, space_id, name):
        """Property key by display name, read from the SPACE's property list.

        An object's own `properties` array only carries properties that HAVE a
        value, so a field left empty in Anytype cannot be found by inspecting
        the object — which failed the write-back with "property 'Status' is not
        on this object" for exactly the fields most likely to need filling in
        (found 2026-08-05 on the partner leg; the project leg had the same
        latent hole for any empty date/number). Cached per space.
        """
        cache = getattr(self, "_pk_cache", None)
        if cache is None:
            cache = self._pk_cache = {}
        if space_id not in cache:
            try:
                cache[space_id] = {
                    (p.get("name") or "").strip().lower(): p.get("key")
                    for p in self._get(f"/v1/spaces/{space_id}/properties",
                                       {"limit": 300}).get("data", [])
                }
            except requests.HTTPError:
                cache[space_id] = {}
        return cache[space_id].get(str(name).strip().lower())

    def find_object_space(self, object_id, space_ids):
        """Which configured space holds this object (one space per project)."""
        for sid in space_ids:
            try:
                self._get(f"/v1/spaces/{sid}/objects/{object_id}")
                return sid
            except requests.HTTPError:
                continue
        return None

    def create_project(self, space_id, name, description, tasks):
        """Create a Project object in this local space (the outbox delivery).
        Returns the new object's id. Tasks (if any) are created as child
        Task objects; failures on those don't fail the project."""
        body = {"type_key": "project", "name": name,
                "properties": [{"key": "description", "text": description or ""}]}
        js = self._post(f"/v1/spaces/{space_id}/objects", body)
        obj = js.get("object", js)
        pid = obj.get("id")
        for t in tasks or []:
            try:
                self._post(f"/v1/spaces/{space_id}/objects",
                           {"type_key": "task", "name": t,
                            "properties": [{"key": "project_link", "objects": [{"id": pid}]}]})
            except requests.HTTPError:
                pass
        return pid


def _find(obj, name):
    ln = name.lower()
    for prop in obj.get("properties") or []:
        if (prop.get("name") or "").lower() == ln:
            return prop
    return None

def prop_text(obj, name):
    p = _find(obj, name)
    if not p:
        return None
    v = p.get("text") or p.get("value")
    return str(v).strip() if v else None

def prop_select(obj, name):
    p = _find(obj, name)
    if not p:
        return None
    sel = p.get("select")
    if isinstance(sel, dict):
        return sel.get("name")
    if isinstance(sel, str):
        return sel
    ms = p.get("multi_select")
    if isinstance(ms, list) and ms:
        first = ms[0]
        return first.get("name") if isinstance(first, dict) else str(first)
    return None

def prop_number(obj, name):
    p = _find(obj, name)
    if not p:
        return None
    v = p.get("number", p.get("value"))
    try:
        return float(v) if v is not None else None
    except (TypeError, ValueError):
        return None


def prop_date(obj, name):
    p = _find(obj, name)
    if not p:
        return None
    v = p.get("date") or p.get("value")
    return str(v)[:10] if v else None

def prop_person_name(obj, name):
    p = _find(obj, name)
    if not p:
        return None
    v = p.get("objects") or p.get("value") or []
    for item in v if isinstance(v, list) else [v]:
        if isinstance(item, dict) and item.get("name"):
            return item["name"]
    return None

def resolve_person_name(at, space_id, obj, name, cache):
    """Owner/Assignee display name. The 2025-05-20 API returns object
    relations as BARE ID STRINGS (objects: ["bafy..."]), so the dict path in
    prop_person_name reads nothing on live 0.55+ (verified 2026-07-27 —
    ownerName was silently null for every project). Fall back to resolving
    each id via object_detail, cached per space."""
    direct = prop_person_name(obj, name)
    if direct:
        return direct
    for oid in prop_object_ids(obj, name):
        if oid not in cache:
            try:
                det = at.object_detail(space_id, oid)
                cache[oid] = (det.get("name") or "").strip() or None
            except requests.HTTPError:
                cache[oid] = None
        if cache[oid]:
            return cache[oid]
    return None

def prop_object_ids(obj, name):
    p = _find(obj, name)
    if not p:
        return []
    v = p.get("objects") or p.get("value") or []
    out = []
    for item in v if isinstance(v, list) else [v]:
        if isinstance(item, dict) and item.get("id"):
            out.append(item["id"])
        elif isinstance(item, str):
            out.append(item)
    return out

def obj_name(obj):
    return (obj.get("name") or prop_text(obj, "Name") or "(untitled)").strip()


# ── Payload builder (typed; the server rejects anything else) ────────────────
def prop_labels(obj, name):
    """Multi-select labels for a property ([] when absent) — Task Force tags."""
    for p in obj.get("properties") or []:
        if (p.get("name") or "").lower() == name.lower():
            return [t.get("name") for t in (p.get("multi_select") or [])
                    if isinstance(t, dict) and t.get("name")]
    return []


# Set from --allow-tf-fallback. Default False: an unresolved Task Force aborts
# the run rather than quietly writing the wrong one.
ALLOW_TF_FALLBACK = False


def resolve_tf(space_id, votes, default_pa, aliases, overrides, quiet=False):
    """Decide a space's SOT problem_area from its projects' own Anytype
    Task Force tags.

    Anytype is the author of record, so the tag on the object decides —
    sync.yml's problem_area_id is only the fallback. It used to be the ONLY
    source, which parked 47 of 59 spaces under "Research hub" whatever their
    real TF said (found 2026-08-05: "the task force names are not synched up").

    Anytype's TF vocabulary is coarser than SOT's problem_areas (one tag,
    "Islamist & NGO Enforcement", spans two of them), so `tf_overrides`
    resolves by project name where a label cannot.
    """
    picks, unresolved = set(), []
    for name, labels in votes:
        pa = overrides.get(name.strip().lower())
        if not pa:
            for lab in labels:
                pa = aliases.get(lab.strip().lower())
                if pa:
                    break
        if pa:
            picks.add(str(pa))
        else:
            unresolved.append((name, labels))
    if len(picks) == 1 and not unresolved:
        return picks.pop()

    # Anything ambiguous is a HARD STOP, not a quiet default.
    #
    # Falling back to sync.yml's problem_area_id is how 43 of 48 projects came to
    # sit under "Research hub": every Task Force whose name SOT did not recognise
    # was silently reassigned, the warning scrolled past, and the portfolio read
    # as if the work did not exist. Migration 0041 aligned the two vocabularies
    # and tf_aliases now covers all eleven names, so an unresolved tag means the
    # vocabularies have drifted apart again — which is exactly the thing that must
    # not pass unnoticed. Add the Task Force to problem_areas (and re-run
    # build_sync_yml.py), or name it in tf_overrides. --allow-tf-fallback restores
    # the old behaviour for a one-off run.
    detail = []
    for name, labels in unresolved:
        detail.append(f"      {name[:50]!r}: "
                      + (f"Task Force {labels[0]!r} is not in tf_aliases" if labels
                         else "has no Task Force tag"))
    if len(picks) > 1:
        detail.append(f"      projects in this space disagree: {len(picks)} different "
                      f"Task Forces")
    msg = (f"cannot resolve the Task Force for space {space_id[:24]}…\n"
           + "\n".join(detail)
           + "\n    Fix the vocabulary rather than defaulting — see resolve_tf().")
    if not ALLOW_TF_FALLBACK:
        raise SystemExit(f"SYNC ABORTED: {msg}")
    if not quiet:
        print(f"  ! {msg}\n    --allow-tf-fallback set: using sync.yml", file=sys.stderr)
    return default_pa


def build_space_payload(at: Anytype, space_id: str, problem_area_id: str,
                        tf_aliases=None, tf_overrides=None, quiet=False) -> dict:
    projects, tasks = [], []
    tf_votes = []       # (project name, [Task Force labels]) — see resolve_tf
    person_cache = {}   # object id -> display name, shared by owners+assignees
    for stub in at.objects_of_type(space_id, "project"):
        obj = at.object_detail(space_id, stub["id"])
        tf_votes.append((obj_name(obj) or "",
                         prop_labels(obj, "Primary Task Force")
                         or prop_labels(obj, "Task Force")))
        projects.append({
            "anytypeObjectId": stub["id"],
            # the space this project lives in — with one space per project a
            # TF-level space id addresses the wrong space (see migration 0037)
            "anytypeSpaceId": space_id,
            "name": obj_name(obj),
            # NO free text ("clandestine DB", Lily 2026-08-02): description and
            # latestUpdate stay in Anytype; the server struct rejects them.
            "status": prop_select(obj, "Status"),
            "priority": prop_select(obj, "Priority"),
            "ownerName": resolve_person_name(at, space_id, obj, "Owner", person_cache),
            "startDate": prop_date(obj, "Start Date"),
            "dueDate": prop_date(obj, "Due Date"),
            # Anytype Budget (number) == SOT planned_budget (the PLANNED figure).
            "budget": prop_number(obj, "Budget"),
        })
    for stub in at.objects_of_type(space_id, "task"):
        obj = at.object_detail(space_id, stub["id"])
        # live contract (0.55): a task links its project via "Project Link",
        # and its person via "Owner" (there is no "Assignee"/"Parent Project").
        parents = prop_object_ids(obj, "Project Link")
        tasks.append({
            "anytypeObjectId": stub["id"],
            "parentProjectAnytypeId": parents[0] if parents else None,
            "name": obj_name(obj),
            "status": prop_select(obj, "Status"),
            "priority": prop_select(obj, "Priority"),
            "assigneeName": resolve_person_name(at, space_id, obj, "Owner", person_cache),
            "dueDate": prop_date(obj, "Due date"),
        })
    # spaceId is the opaque Anytype space id (not a name) — the server persists it
    # to problem_areas.anytype_space_id so the UI can build the drill-out deep link.
    pa = resolve_tf(space_id, tf_votes, problem_area_id,
                    tf_aliases or {}, tf_overrides or {}, quiet=quiet)
    return {"problemAreaId": pa, "spaceId": space_id,
            "projects": projects, "tasks": tasks}


# ── Tokenization (docs/TOKENIZATION_VAULT_HANDOFF.md) ────────────────────────
# Keyed on anytypeObjectId — the IDENTITY, never the display string. The
# server only ever receives tokens for sensitive entities. Free text is
# LINTED (warn), never auto-tokenized. Minting is deliberate: unseen uuids
# are queued for the mint authority, NOT silently minted.
def tokenize_payload(payload_spaces, vault, mint_queue, lint_hits):
    names = vault.active_plaintexts()   # plaintext -> token, for the lint

    def lint(text, where):
        if not text:
            return
        for plain in names:
            if plain and plain in text:
                lint_hits.append(f"{where}: free text contains sensitive value "
                                 f"{plain!r} (refer to it by its token {names[plain]})")

    def tok_entity(obj_id, plaintext, namespace):
        tok = vault.token_for(obj_id)
        if tok:
            return tok
        # miss -> queue for a deliberate mint, do NOT auto-mint, do NOT ship plaintext
        if not any(q["anytype_uuid"] == obj_id for q in mint_queue):
            mint_queue.append({"anytype_uuid": obj_id, "namespace": namespace,
                               "plaintext": plaintext})
        return None   # withheld until minted

    for space in payload_spaces:
        for pr in space["projects"]:
            # (free-text fields no longer exist in the payload — nothing to lint)
            pr["name"] = tok_entity(pr["anytypeObjectId"], pr["name"], "proj")
            if pr.get("ownerName"):
                # owner is a person entity in its own right; tokenized only if
                # that person is in the vault (person tier per handoff §8.2)
                pr["ownerName"] = vault.token_for("person:" + pr["ownerName"]) or pr["ownerName"]
        for tk in space["tasks"]:
            tk["name"] = tok_entity(tk["anytypeObjectId"], tk["name"], "proj")
    # projects/tasks whose token isn't minted yet are dropped from this push
    for space in payload_spaces:
        space["projects"] = [p for p in space["projects"] if p["name"] is not None]
        space["tasks"] = [t for t in space["tasks"] if t["name"] is not None]


# ── Sealed-intake delivery (INTAKE_V3_PLAN §2.4/§5A) ─────────────────────────
SEALBOX_KEYRING_ENTRY = "sealbox_private_pem"


def _load_sealbox_key():
    """The lead's sealbox private key (PEM) from the OS keyring / env.
    Same custody as the Anytype + API tokens — never on disk in the clear."""
    import sealbox  # noqa: PLC0415
    pem = os.environ.get("SOTC_SEALBOX_PRIVATE_PEM")
    if not pem:
        try:
            import keyring  # noqa: PLC0415
            pem = keyring.get_password(KEYRING_SERVICE, SEALBOX_KEYRING_ENTRY)
        except Exception as e:  # noqa: BLE001
            raise SystemExit(f"keyring unavailable ({e}); run --register-key first") from e
    if not pem:
        raise SystemExit("no sealbox key on this machine — run: sync_client.py --register-key")
    return sealbox.key_from_pem(pem)


def register_key(server, http) -> int:
    """Generate the machine keypair, store the private key in the keyring,
    register the PUBLIC key with the server over the Bearer token."""
    import sealbox  # noqa: PLC0415
    token = get_secret("api_token", "SOTC_API_TOKEN")
    priv = sealbox.generate_keypair()
    pub = sealbox.public_jwk(priv)
    fp = sealbox.fingerprint(pub)
    label = f"lead key {os.environ.get('COMPUTERNAME') or os.uname().nodename if hasattr(os, 'uname') else 'machine'}"
    r = requests.post(f"{server}/api/register_lead_key",
                      json={"label": label, "publicKeyJwk": pub},
                      headers={"Authorization": f"Bearer {token}"}, timeout=30, **http)
    if r.status_code != 200:
        print(f"register FAILED [{r.status_code}]: {r.text}", file=sys.stderr)
        return 1
    try:
        import keyring  # noqa: PLC0415
        keyring.set_password(KEYRING_SERVICE, SEALBOX_KEYRING_ENTRY, sealbox.private_pem(priv))
        stored = "OS keyring"
    except Exception:  # noqa: BLE001
        print("WARNING: keyring unavailable — private key printed once, store it as "
              "SOTC_SEALBOX_PRIVATE_PEM:", file=sys.stderr)
        print(sealbox.private_pem(priv))
        stored = "env (printed above)"
    print(f"registered lead key: fingerprint {fp}")
    print(f"private key stored in: {stored}")
    print("Verify this fingerprint with the triager out-of-band before they promote to you.")
    return 0


def run_outbox(server, http, spaces) -> int:
    """Pull pending intake→project items for our TFs, unseal locally, create
    them in the local Anytype, and ack. The next --push carries them into SOT."""
    import sealbox  # noqa: PLC0415
    token = get_secret("api_token", "SOTC_API_TOKEN")
    pa_to_space = {str(sp["problem_area_id"]): str(sp["space_id"]) for sp in spaces}

    r = requests.get(f"{server}/api/outbox_pending",
                     headers={"Authorization": f"Bearer {token}"}, timeout=60, **http)
    # outbox_pending is POST on the server (uniform ingest surface); fall back.
    if r.status_code == 405:
        r = requests.post(f"{server}/api/outbox_pending",
                          headers={"Authorization": f"Bearer {token}"}, timeout=60, **http)
    if r.status_code != 200:
        print(f"outbox fetch FAILED [{r.status_code}]: {r.text}", file=sys.stderr)
        return 1
    items = r.json()
    if not items:
        print("outbox: nothing pending.")
        return 0

    priv = _load_sealbox_key()
    at = Anytype(get_secret("anytype_api_token", "ANYTYPE_API_TOKEN"))
    ok = fail = 0
    for it in items:
        oid = it["id"]
        try:
            space_id = pa_to_space.get(it["problemAreaId"])
            if not space_id:
                raise RuntimeError(f"no local space mapped for TF {it['tfName']} ({it['problemAreaId']})")
            payload = json.loads(sealbox.unseal(priv, it["sealedPayload"]))
            new_id = at.create_project(space_id, payload["projectName"],
                                       payload.get("description", ""), payload.get("tasks"))
            ack = requests.post(f"{server}/api/outbox_ack",
                                json={"id": oid, "anytypeObjectId": new_id},
                                headers={"Authorization": f"Bearer {token}"}, timeout=30, **http)
            ack.raise_for_status()
            print(f"delivered → {it['tfName']}: '{payload['projectName']}' = {new_id}")
            ok += 1
        except Exception as e:  # noqa: BLE001
            reason = str(e)[:200]
            try:
                requests.post(f"{server}/api/outbox_ack",
                              json={"id": oid, "failReason": reason},
                              headers={"Authorization": f"Bearer {token}"}, timeout=30, **http)
            except Exception:  # noqa: BLE001
                pass
            print(f"FAILED {oid}: {reason}", file=sys.stderr)
            fail += 1
    print(f"outbox: {ok} delivered, {fail} failed. Run --push to sync them into SOT.")
    return 0 if fail == 0 else 1


# ── Write-back leg: drain SOT's edit queue into Anytype ─────────────────────
# SOT records INTENT (anytype_edit_queue, migration 0039); this applies it with
# COMPARE-AND-SET: if Anytype moved since the request, we do NOT patch — the row
# is reported 'conflict' and a human decides. Anytype stays the source of truth;
# the same cycle's pull is what confirms the change back into SOT.
EDIT_FIELDS = {
    "status":        ("Status",     "select"),
    "priority":      ("Priority",   "select"),
    "startDate":     ("Start Date", "date"),
    "dueDate":       ("Due date",   "date"),
    "plannedBudget": ("Budget",     "number"),
}
# SOT canonical value -> acceptable Anytype option labels, best first. A space
# may define several equivalents ("Active" AND "In Progress"), so we try in order
# against the property's REAL option list (verified 2026-08-02).
STATUS_OUT = {
    "not_started": ["Backlog", "To Do", "Not Started"],
    "in_progress": ["Active", "In Progress"],
    "blocked":     ["Blocked"],
    "on_hold":     ["On Hold", "Paused"],
    "done":        ["Done", "Complete", "Completed"],
    "cancelled":   ["Cancelled", "Canceled", "Dropped"],
}
PRIORITY_OUT = {"critical": ["Critical"], "high": ["High"],
                "medium": ["Medium"], "low": ["Low"]}


def _labels_for(field, value):
    """Candidate Anytype labels for a SOT canonical value."""
    if value in (None, ""):
        return []
    table = STATUS_OUT if field == "status" else PRIORITY_OUT if field == "priority" else {}
    return table.get(str(value), [str(value)])


def _label_for(field, value):
    labs = _labels_for(field, value)
    return labs[0] if labs else value


def _read_current(obj, prop, kind):
    if kind == "select":
        return prop_select(obj, prop)
    if kind == "date":
        return prop_date(obj, prop)
    n = prop_number(obj, prop)
    return None if n is None else str(n)


def _same(field, kind, anytype_value, sot_value):
    """Does Anytype's current value match what SOT believed was current?"""
    if kind == "select":
        cur = (str(anytype_value).strip().lower() if anytype_value not in (None, "") else "")
        want = {l.lower() for l in _labels_for(field, sot_value)}
        # also accept the raw canonical form (e.g. "high") for hand-set values
        if sot_value not in (None, ""):
            want.add(str(sot_value).strip().lower())
        return (cur in want) if want else cur == ""

    def norm(v):
        if v in (None, ""):
            return ""
        s = str(v).strip()
        if kind == "date":
            return s[:10]
        try:
            return str(float(s))
        except ValueError:
            return s.lower()
    return norm(anytype_value) == norm(sot_value)


def _prop_key(obj, prop):
    for pr in obj.get("properties") or []:
        if (pr.get("name") or "").lower() == prop.lower():
            return pr.get("key")
    return None


def run_edits(at, server, http, spaces, quiet=False,
              pending_ep="edits_pending", ack_ep="edits_ack", label="edits"):
    """Pull pending edits -> compare-and-set -> PATCH -> ack.

    Generic over the queue: projects (0039, the defaults) and tasks (0042,
    task_edits_pending/task_edits_ack). Both queues carry the same row shape
    and the object id is looked up across the same spaces, so one drain
    serves both — the task queue's DB CHECK limits it to status/priority/
    dueDate, all of which EDIT_FIELDS already maps.
    """
    token = get_secret("api_token", "SOTC_API_TOKEN")
    hdr = {"Authorization": f"Bearer {token}"}
    try:
        r = requests.post(f"{server}/api/{pending_ep}", json={}, headers=hdr, timeout=60, **http)
    except requests.RequestException as ex:
        print(f"{label}: server unreachable ({ex})", file=sys.stderr)
        return
    if r.status_code != 200:
        print(f"{label}: pull failed [{r.status_code}]: {r.text[:200]}", file=sys.stderr)
        return
    pending = r.json()
    if not pending:
        return

    space_ids = [str(sp["space_id"]) for sp in spaces]
    tally = {"applied": 0, "conflict": 0, "failed": 0}
    for item in pending:
        eid, oid, field = item["id"], item["anytypeObjectId"], item["field"]
        want, expected = item.get("newValue"), item.get("expectedOldValue")
        status, reason = "failed", None
        try:
            if field not in EDIT_FIELDS:
                raise RuntimeError(f"field '{field}' is not writable")
            prop, kind = EDIT_FIELDS[field]
            sid = at.find_object_space(oid, space_ids)
            if not sid:
                raise RuntimeError("object not found in any configured space")
            obj = at.object_detail(sid, oid)
            current = _read_current(obj, prop, kind)
            if not _same(field, kind, current, expected):
                status = "conflict"
                reason = f"Anytype has {current!r}; the request expected {expected!r}"
            else:
                # object properties list only non-empty fields — fall back to
                # the space's property list (see space_prop_key).
                key = _prop_key(obj, prop) or at.space_prop_key(sid, prop)
                if not key:
                    raise RuntimeError(f"property {prop!r} is not on this object")
                body = {"key": key}
                if want in (None, ""):
                    body["number" if kind == "number" else kind] = None
                elif kind == "select":
                    # live 0.55 wants the OPTION ID as a plain string here — an
                    # object 400s ("cannot unmarshal object … of type string")
                    # and so does a bare label ("invalid select option").
                    opt_id, used = at.select_option_id(sid, key, _labels_for(field, want))
                    if not opt_id:
                        raise RuntimeError(
                            f"no Anytype option for {field}={want!r} "
                            f"(tried {_labels_for(field, want)})")
                    body["select"] = opt_id
                elif kind == "date":
                    body["date"] = want
                else:
                    body["number"] = float(want)
                at.patch_object(sid, oid, [body])
                status = "applied"
        except Exception as ex:  # noqa: BLE001 — one bad row must not stop the leg
            if status != "conflict":
                status, reason = "failed", str(ex)[:200]
        try:
            requests.post(f"{server}/api/{ack_ep}",
                          json={"id": eid, "status": status, "failReason": reason},
                          headers=hdr, timeout=30, **http)
        except requests.RequestException:
            pass
        tally[status] += 1
        if not quiet:
            print(f"  edit {field}: {status}" + (f" — {reason}" if reason else ""), file=sys.stderr)
    print(f"{label}: {tally['applied']} applied, {tally['conflict']} conflict, "
          f"{tally['failed']} failed", file=sys.stderr)


# ── Partners, both ways (migration 0040) ─────────────────────────────────────
# Partners live in ONE Anytype directory space (config: partners_space_id), not
# per task force, and the join key is the "SOT ID" text property (P-001) — which
# is ALSO the vault key (partner:P-001) minted by tokenization/partner_seed.py.
# Reusing that key is what keeps DERWENT called DERWENT; minting from here would
# silently rename every partner.

def build_partners_payload(at: Anytype, space_id: str, vault, quiet=False):
    """Read Partner objects -> tokenized payload for POST /api/partners_sync.

    Free text (Availability) is deliberately NOT read: the server's struct
    would reject it anyway (deny_unknown_fields), and the clandestine rule is
    that notes stay in Anytype.
    """
    out, skipped = [], []
    for stub in at.objects_of_type(space_id, "partner"):
        obj = at.object_detail(space_id, stub["id"])
        sot_id = (prop_text(obj, "SOT ID") or "").strip()
        real_name = obj_name(obj) or ""
        if not sot_id:
            skipped.append(f"{real_name[:32]!r}: no SOT ID — cannot be matched")
            continue
        # token_for ONLY — never mint here. A partner absent from the vault is a
        # partner the workbook loader has not seen, and the server would reject
        # its id anyway.
        token = vault.token_for(f"partner:{sot_id}") if vault else None
        if not token:
            skipped.append(f"{sot_id}: not in the vault (run tokenization/partner_seed.py first)")
            continue
        out.append({
            "sotId": sot_id,
            "anytypeObjectId": stub["id"],
            "name": token,
            "category": prop_select(obj, "Category"),
            "status": prop_select(obj, "Status"),
            "skills": prop_labels(obj, "Skills"),
        })
    if skipped and not quiet:
        for s in skipped:
            print(f"  ! partner {s}", file=sys.stderr)
    return out


def push_partners(server, http, payload, quiet=False):
    if not payload:
        print("partners: nothing to send", file=sys.stderr)
        return
    token = get_secret("api_token", "SOTC_API_TOKEN")
    try:
        r = requests.post(f"{server}/api/partners_sync", json={"partners": payload},
                          headers={"Authorization": f"Bearer {token}"}, timeout=120, **http)
    except requests.RequestException as ex:
        print(f"partners: server unreachable ({ex})", file=sys.stderr)
        return
    if r.status_code != 200:
        print(f"partners: push failed [{r.status_code}]: {r.text[:300]}", file=sys.stderr)
        return
    res = r.json()
    print(f"partners: {res.get('matched', 0)} matched, {res.get('updated', 0)} updated "
          f"as {res.get('submittedAs', '?')}", file=sys.stderr)
    for w in res.get("warnings") or []:
        print(f"  ! {w}", file=sys.stderr)
    unknown = res.get("unknownSotIds") or []
    if unknown:
        print(f"  ! {len(unknown)} SOT ID(s) not in SOT: {', '.join(unknown[:8])}"
              f"{' …' if len(unknown) > 8 else ''}", file=sys.stderr)


def run_partner_edits(at, server, http, space_id, quiet=False):
    """Drain partner_edit_queue: compare-and-set -> PATCH the select -> ack.

    The server hands us LABELS (it joined the ref_* tables), because Anytype
    selects are labels — and the PATCH itself needs the option ID, resolved the
    same way as run_edits.
    """
    token = get_secret("api_token", "SOTC_API_TOKEN")
    hdr = {"Authorization": f"Bearer {token}"}
    try:
        r = requests.post(f"{server}/api/partner_edits_pending", json={}, headers=hdr,
                          timeout=60, **http)
    except requests.RequestException as ex:
        print(f"partner edits: server unreachable ({ex})", file=sys.stderr)
        return
    if r.status_code != 200:
        print(f"partner edits: pull failed [{r.status_code}]: {r.text[:200]}", file=sys.stderr)
        return
    pending = r.json()
    if not pending:
        return

    PROP = {"category": "Category", "status": "Status"}
    tally = {"applied": 0, "conflict": 0, "failed": 0}
    for item in pending:
        eid, oid, field = item["id"], item["anytypeObjectId"], item["field"]
        want_label = item.get("newLabel")
        expected = item.get("expectedOldLabel")
        status, reason = "failed", None
        try:
            prop = PROP.get(field)
            if not prop:
                raise RuntimeError(f"field '{field}' is not writable")
            obj = at.object_detail(space_id, oid)
            current = prop_select(obj, prop)
            # Same compare-and-set rule as projects: what Anytype holds now must
            # be what SOT believed, or the user is overwriting someone's edit.
            #
            # EXCEPT when Anytype holds nothing. The Partner objects were created
            # by partner_upload.py with Category/Status left empty (verified
            # 2026-08-05: 0 of 23 had either), while SOT carries the workbook's
            # seeded codes — so a strict compare would report "conflict" on every
            # first edit. An empty field cannot be someone else's edit being
            # clobbered, so an empty base is accepted and filled.
            if current and (current or "").strip().lower() != (expected or "").strip().lower():
                status = "conflict"
                reason = f"Anytype has {current!r}; the request expected {expected!r}"
            else:
                # Resolve through the Partner TYPE: the space has two "Status"
                # properties sharing the key, and only the type says which one
                # this object means (see type_prop).
                prop_id, key = at.type_prop(space_id, "partner", prop)
                key = key or _prop_key(obj, prop)
                if not key or not prop_id:
                    raise RuntimeError(f"the Partner type has no {prop!r} property")
                opt_id = at.ensure_select_option(space_id, prop_id, key, want_label)
                if not opt_id:
                    raise RuntimeError(f"no Anytype option for {field}={want_label!r} "
                                       f"and it could not be created")
                at.patch_object(space_id, oid, [{"key": key, "select": opt_id}])
                status = "applied"
        except Exception as ex:  # noqa: BLE001 — one bad row must not stop the leg
            if status != "conflict":
                status, reason = "failed", str(ex)[:200]
        try:
            requests.post(f"{server}/api/partner_edits_ack",
                          json={"id": eid, "status": status, "failReason": reason},
                          headers=hdr, timeout=30, **http)
        except requests.RequestException:
            pass
        tally[status] += 1
        if not quiet:
            print(f"  partner edit {field}: {status}" + (f" — {reason}" if reason else ""),
                  file=sys.stderr)
    print(f"partner edits: {tally['applied']} applied, {tally['conflict']} conflict, "
          f"{tally['failed']} failed", file=sys.stderr)


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")

    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--dry-run", action="store_true", help="print the exact payload, send nothing")
    mode.add_argument("--push", action="store_true", help="send the payload")
    mode.add_argument("--register-key", action="store_true",
                      help="generate this machine's sealbox keypair (private → keyring), register the public key with the server")
    mode.add_argument("--outbox", action="store_true",
                      help="deliver pending intake→project items into the local Anytype, then ack the server")
    mode.add_argument("--daemon", type=int, nargs="?", const=10, metavar="MINUTES",
                      help="run continuously: push every N minutes (default 10). The vault "
                           "passphrase is entered ONCE and held only in this process's memory "
                           "— never written anywhere. Ctrl+C stops. SOT becomes a live front "
                           "end to the Anytype projects.")
    ap.add_argument("--config", default=str(Path(__file__).with_name("sync.yml")))
    ap.add_argument("--server", help="override the config's server URL")
    ap.add_argument("--cert", help="mTLS client certificate (PEM)")
    ap.add_argument("--key", help="mTLS client key (PEM)")
    ap.add_argument("--insecure", action="store_true",
                    help="skip server TLS verification (local staging with Caddy's self-signed cert ONLY)")
    ap.add_argument("--vault", help="path to the tokenization vault (or set vault: in config)")
    ap.add_argument("--allow-tf-fallback", action="store_true",
                    help="do not abort when a Task Force cannot be resolved; fall "
                         "back to sync.yml's problem_area_id (the old behaviour, "
                         "which silently misfiled 43 of 48 projects)")
    args = ap.parse_args()
    global ALLOW_TF_FALLBACK
    ALLOW_TF_FALLBACK = args.allow_tf_fallback

    cfg_path = Path(args.config)
    if not cfg_path.is_file():
        raise SystemExit(f"{cfg_path} not found — the admin generates your sync.yml (see anytype_sync/README.md).")
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
    spaces = cfg.get("spaces") or []
    if not spaces:
        raise SystemExit(f"{cfg_path}: no 'spaces' entries.")
    # Task Force resolution (see resolve_tf): Anytype's own tag decides, keyed
    # case-insensitively. tf_overrides is by project name, for the tags whose
    # vocabulary is coarser than SOT's problem_areas.
    tf_aliases = {str(k).strip().lower(): v for k, v in (cfg.get("tf_aliases") or {}).items()}
    tf_overrides = {str(k).strip().lower(): v for k, v in (cfg.get("tf_overrides") or {}).items()}
    # Partners (0040) live in ONE Anytype directory space, addressed by id.
    # Absent = the partner legs are simply skipped, both ways.
    partners_space = cfg.get("partners_space_id")
    server = args.server or cfg.get("server") or "http://127.0.0.1:8443"
    cert = args.cert or cfg.get("cert")
    key = args.key or cfg.get("key")

    # HTTP kwargs shared by every server call (mTLS cert + TLS verification).
    http = {}
    if cert and key:
        http["cert"] = (cert, key)
    if args.insecure:
        http["verify"] = False
        import urllib3
        urllib3.disable_warnings()

    # ── Mode: register this machine's sealbox key (sealed-intake delivery) ──
    if args.register_key:
        return register_key(server, http)

    # ── Mode: deliver pending intake→project items into local Anytype ──
    if args.outbox:
        return run_outbox(server, http, spaces)

    # ── One read→tokenize→push cycle (shared by --dry-run/--push/--daemon) ──
    vault_path = args.vault or cfg.get("vault")
    quiet = args.daemon is not None   # daemon: keep per-space chatter down

    def one_cycle(vpw: str | None) -> int:
        at = Anytype(get_secret("anytype_api_token", "ANYTYPE_API_TOKEN"))
        # Write-back FIRST so this cycle's pull carries the applied values back —
        # Anytype stays the source of truth and the pull is the confirmation.
        if not args.dry_run:
            run_edits(at, server, http, spaces, quiet=quiet)
            # Task write-back (0042): same drain, the task queue's endpoints.
            run_edits(at, server, http, spaces, quiet=quiet,
                      pending_ep="task_edits_pending", ack_ep="task_edits_ack",
                      label="task edits")
            if partners_space:
                run_partner_edits(at, server, http, partners_space, quiet=quiet)
        payload_spaces = []
        try:
            for sp in spaces:
                payload_spaces.append(
                    build_space_payload(at, str(sp["space_id"]), str(sp["problem_area_id"]),
                                        tf_aliases, tf_overrides, quiet=quiet))
                if not quiet:
                    n = payload_spaces[-1]
                    print(f"{sp.get('name', sp['problem_area_id'])}: "
                          f"{len(n['projects'])} projects, {len(n['tasks'])} tasks", file=sys.stderr)
        except requests.ConnectionError:
            print("Anytype is not running (localhost API unreachable). Nothing sent.", file=sys.stderr)
            return 2

        vault_version = None
        partners_payload = []
        mint_queue, lint_hits = [], []
        if vault_path:
            from vault import Vault  # noqa: PLC0415
            vault = Vault.open(Path(vault_path), vpw)
            vault_version = vault.version
            # Partners are keyed on their SOT ID, already minted by
            # partner_seed.py — this leg only LOOKS UP tokens (see the function).
            if partners_space:
                partners_payload = build_partners_payload(at, partners_space, vault, quiet=quiet)
            tokenize_payload(payload_spaces, vault, mint_queue, lint_hits)
            for h in lint_hits:
                print(f"LINT: {h}", file=sys.stderr)
            if mint_queue:
                qpath = Path(vault_path).with_name("pending_mints.json")
                existing = json.loads(qpath.read_text(encoding="utf-8")) if qpath.is_file() else []
                seen = {q["anytype_uuid"] for q in existing}
                existing += [q for q in mint_queue if q["anytype_uuid"] not in seen]
                qpath.write_text(json.dumps(existing, indent=1), encoding="utf-8")
                print(f"NOTE: {len(mint_queue)} unseen entit(y/ies) queued for minting in "
                      f"{qpath.name} — the mint authority runs vault_tool.py mint, "
                      f"redistributes the vault, then you re-sync. Those rows are held back "
                      f"from this push (never sent as plaintext).", file=sys.stderr)

        payload = {"spaces": payload_spaces}
        if vault_version is not None:
            payload["vaultVersion"] = vault_version   # skew stamp (handoff §5)
        if args.dry_run:
            # Two separate endpoints, so show both payloads rather than pretending
            # partners ride along inside the /api/sync body.
            print(json.dumps({"sync": payload, "partners": partners_payload},
                             indent=2, ensure_ascii=False))
            print(f"\n(dry-run: nothing sent; --push would POST to {server}/api/sync"
                  + (f", plus {len(partners_payload)} partner(s) to /api/partners_sync)"
                     if partners_payload else ")"), file=sys.stderr)
            return 0

        token = get_secret("api_token", "SOTC_API_TOKEN")
        r = requests.post(f"{server}/api/sync", json=payload,
                          headers={"Authorization": f"Bearer {token}"}, timeout=120, **http)
        if r.status_code != 200:
            print(f"push FAILED [{r.status_code}]: {r.text}", file=sys.stderr)
            return 1
        res = r.json()
        np = sum(s["projects"] for s in res["spaces"])
        nt = sum(s["tasks"] for s in res["spaces"])
        warns = [w for s in res["spaces"] for w in s["warnings"]]
        if quiet:
            print(f"push ok as {res['submittedAs']}: {np}p {nt}t across {len(res['spaces'])} spaces"
                  + (f" — {len(warns)} warning(s)" if warns else ""))
        else:
            for s in res["spaces"]:
                print(f"ok {s['problemAreaId']}: {s['projects']}p {s['tasks']}t"
                      + (f" — {len(s['warnings'])} warning(s): {'; '.join(s['warnings'][:3])}" if s["warnings"] else ""))
            print(f"push ok as {res['submittedAs']}")
        # Partners last: they are independent of the /api/sync result, and a
        # partner-side failure must not make a good project push look failed.
        if partners_space:
            push_partners(server, http, partners_payload, quiet=quiet)
        return 0

    # Passphrase: once, up front, memory-only (never written; the human step).
    vpw = None
    if vault_path:
        vpw = os.environ.get("SOTC_VAULT_PASSPHRASE")
        if not vpw:
            import getpass
            vpw = getpass.getpass("vault passphrase: ")

    if args.daemon is None:
        return one_cycle(vpw)

    # ── Daemon: SOT DB as a LIVE front end to the Anytype projects ──────
    import time
    from datetime import datetime
    interval = max(1, args.daemon)
    print(f"sync daemon: pushing every {interval} min (Ctrl+C stops). "
          f"Vault passphrase held in memory only.", file=sys.stderr)
    while True:
        stamp = datetime.now().strftime("%H:%M:%S")
        try:
            rc = one_cycle(vpw)
            if rc != 0:
                print(f"[{stamp}] cycle returned {rc} — retrying in {interval} min", file=sys.stderr)
        except KeyboardInterrupt:
            raise
        except Exception as ex:  # noqa: BLE001 — a bad cycle must not kill the daemon
            print(f"[{stamp}] cycle error: {ex} — retrying in {interval} min", file=sys.stderr)
        try:
            time.sleep(interval * 60)
        except KeyboardInterrupt:
            print("daemon stopped.", file=sys.stderr)
            return 0


if __name__ == "__main__":
    sys.exit(main())
